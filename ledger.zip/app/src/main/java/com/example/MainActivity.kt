package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.Calculate
import androidx.compose.material.icons.outlined.CloudSync
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.DateRange
import androidx.compose.material.icons.outlined.FormatListBulleted
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.dialogs.AddEditPlanDialog
import com.example.ui.dialogs.AddEditTransactionSheet
import com.example.ui.dialogs.AddRuleDialog
import com.example.ui.dialogs.BudgetSettingsDialog
import com.example.ui.dialogs.CalculatorDialog
import com.example.ui.dialogs.DailyRateCalculatorDialog
import com.example.ui.dialogs.GoogleSyncDialog
import com.example.ui.screens.AccountabilityScreen
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.OverviewScreen
import com.example.ui.screens.PlansScreen
import com.example.ui.screens.SettingsSyncScreen
import com.example.ui.screens.TransactionsScreen
import com.example.ui.theme.LedgerTrackTheme
import com.example.ui.viewmodel.FinanceViewModel
import com.example.ui.viewmodel.ScreenTab
import kotlinx.coroutines.flow.collectLatest

class MainActivity : ComponentActivity() {
    private val viewModel: FinanceViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val appTheme by viewModel.appTheme.collectAsStateWithLifecycle()
            val isDarkTheme by viewModel.isDarkTheme.collectAsStateWithLifecycle()

            LedgerTrackTheme(
                appTheme = appTheme,
                darkTheme = isDarkTheme
            ) {
                MainAppContent(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppContent(viewModel: FinanceViewModel) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val selectedMonth by viewModel.selectedMonth.collectAsStateWithLifecycle()
    val monthlySummary by viewModel.monthlySummary.collectAsStateWithLifecycle()
    val monthlyTransactions by viewModel.monthlyTransactions.collectAsStateWithLifecycle()
    val allTransactions by viewModel.allTransactions.collectAsStateWithLifecycle()
    val filteredTransactions by viewModel.filteredTransactions.collectAsStateWithLifecycle()
    val filterState by viewModel.filterState.collectAsStateWithLifecycle()
    val budgetSettings by viewModel.budgetSettings.collectAsStateWithLifecycle()
    val accountabilityRules by viewModel.accountabilityRules.collectAsStateWithLifecycle()
    val plans by viewModel.plans.collectAsStateWithLifecycle()
    val currencySymbol by viewModel.currencySymbol.collectAsStateWithLifecycle()
    val appTheme by viewModel.appTheme.collectAsStateWithLifecycle()
    val isDarkTheme by viewModel.isDarkTheme.collectAsStateWithLifecycle()

    // Dialog & Sheet states
    val showAddSheet by viewModel.showAddTransactionSheet.collectAsStateWithLifecycle()
    val editingTransaction by viewModel.editingTransaction.collectAsStateWithLifecycle()
    val showDailyRateDialog by viewModel.showDailyRateDialog.collectAsStateWithLifecycle()
    val showAddRuleDialog by viewModel.showAddRuleDialog.collectAsStateWithLifecycle()
    val showBudgetSettingsDialog by viewModel.showBudgetSettingsDialog.collectAsStateWithLifecycle()
    val showSyncDialog by viewModel.showSyncDialog.collectAsStateWithLifecycle()

    // Plans and Calculator dialog states
    val showAddPlanDialog by viewModel.showAddPlanDialog.collectAsStateWithLifecycle()
    val editingPlan by viewModel.editingPlan.collectAsStateWithLifecycle()
    val showCalculatorDialog by viewModel.showCalculatorDialog.collectAsStateWithLifecycle()
    val calculatorInitialExpression by viewModel.calculatorInitialExpression.collectAsStateWithLifecycle()

    // Google sync state
    val googleAccount by viewModel.googleAccount.collectAsStateWithLifecycle()
    val isSyncing by viewModel.isSyncing.collectAsStateWithLifecycle()
    val lastSyncedTime by viewModel.lastSyncedTime.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        viewModel.snackbarEvent.collectLatest { message ->
            snackbarHostState.showSnackbar(message)
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_app_icon_wallet_chart_1787950416463),
                            contentDescription = "Ledger App Logo",
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(10.dp)),
                            contentScale = ContentScale.Crop
                        )
                        Column {
                            Text(
                                text = when (currentTab) {
                                    ScreenTab.OVERVIEW -> "Monthly Pulse"
                                    ScreenTab.TRANSACTIONS -> "Monthly Ledger"
                                    ScreenTab.PLANS -> "Next Months Plan"
                                    ScreenTab.ANALYTICS -> "Financial Insights"
                                    ScreenTab.ACCOUNTABILITY -> "Rules & Mantras"
                                    ScreenTab.SYNC_SETTINGS -> "Sync & Settings"
                                },
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(androidx.compose.foundation.shape.CircleShape)
                                        .background(if (googleAccount != null) Color(0xFF4ADE80) else MaterialTheme.colorScheme.primary)
                                )
                                Text(
                                    text = if (googleAccount != null) "SYNCED WITH GOOGLE" else "53/24/23 AUTO-BUDGET",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontSize = 9.sp,
                                        letterSpacing = 0.8.sp,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                },
                actions = {
                    androidx.compose.material3.IconButton(
                        onClick = { viewModel.openCalculator() },
                        modifier = Modifier.testTag("top_bar_calculator_btn")
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(androidx.compose.foundation.shape.CircleShape)
                                .background(MaterialTheme.colorScheme.surfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Calculate,
                                contentDescription = "Quick Calculator",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    androidx.compose.material3.IconButton(
                        onClick = { viewModel.openSyncDialog() },
                        modifier = Modifier.padding(end = 4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(androidx.compose.foundation.shape.CircleShape)
                                .background(MaterialTheme.colorScheme.surfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isSyncing) Icons.Default.CloudSync else Icons.Outlined.CloudSync,
                                contentDescription = "Cloud Sync",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground
                )
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = currentTab == ScreenTab.OVERVIEW,
                    onClick = { viewModel.selectTab(ScreenTab.OVERVIEW) },
                    icon = {
                        Icon(
                            if (currentTab == ScreenTab.OVERVIEW) Icons.Default.Dashboard else Icons.Outlined.Dashboard,
                            contentDescription = "Overview"
                        )
                    },
                    label = { Text("Overview", fontSize = 11.sp) },
                    modifier = Modifier.testTag("nav_overview")
                )

                NavigationBarItem(
                    selected = currentTab == ScreenTab.TRANSACTIONS,
                    onClick = { viewModel.selectTab(ScreenTab.TRANSACTIONS) },
                    icon = {
                        Icon(
                            if (currentTab == ScreenTab.TRANSACTIONS) Icons.Default.FormatListBulleted else Icons.Outlined.FormatListBulleted,
                            contentDescription = "Ledger"
                        )
                    },
                    label = { Text("Ledger", fontSize = 11.sp) },
                    modifier = Modifier.testTag("nav_transactions")
                )

                NavigationBarItem(
                    selected = currentTab == ScreenTab.PLANS,
                    onClick = { viewModel.selectTab(ScreenTab.PLANS) },
                    icon = {
                        Icon(
                            if (currentTab == ScreenTab.PLANS) Icons.Default.DateRange else Icons.Outlined.DateRange,
                            contentDescription = "Plans"
                        )
                    },
                    label = { Text("Plans", fontSize = 11.sp) },
                    modifier = Modifier.testTag("nav_plans")
                )

                NavigationBarItem(
                    selected = currentTab == ScreenTab.ANALYTICS,
                    onClick = { viewModel.selectTab(ScreenTab.ANALYTICS) },
                    icon = {
                        Icon(
                            if (currentTab == ScreenTab.ANALYTICS) Icons.Default.BarChart else Icons.Outlined.BarChart,
                            contentDescription = "Analytics"
                        )
                    },
                    label = { Text("Analytics", fontSize = 11.sp) },
                    modifier = Modifier.testTag("nav_analytics")
                )

                NavigationBarItem(
                    selected = currentTab == ScreenTab.ACCOUNTABILITY,
                    onClick = { viewModel.selectTab(ScreenTab.ACCOUNTABILITY) },
                    icon = {
                        Icon(
                            if (currentTab == ScreenTab.ACCOUNTABILITY) Icons.Default.Security else Icons.Outlined.Security,
                            contentDescription = "Rules"
                        )
                    },
                    label = { Text("Rules", fontSize = 11.sp) },
                    modifier = Modifier.testTag("nav_accountability")
                )

                NavigationBarItem(
                    selected = currentTab == ScreenTab.SYNC_SETTINGS,
                    onClick = { viewModel.selectTab(ScreenTab.SYNC_SETTINGS) },
                    icon = {
                        Icon(
                            if (currentTab == ScreenTab.SYNC_SETTINGS) Icons.Default.CloudSync else Icons.Outlined.CloudSync,
                            contentDescription = "Sync"
                        )
                    },
                    label = { Text("Sync", fontSize = 11.sp) },
                    modifier = Modifier.testTag("nav_sync")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                ScreenTab.OVERVIEW -> {
                    OverviewScreen(
                        selectedMonth = selectedMonth,
                        summary = monthlySummary,
                        budgetSettings = budgetSettings,
                        transactions = monthlyTransactions,
                        rules = accountabilityRules,
                        currencySymbol = currencySymbol,
                        onPreviousMonth = { viewModel.previousMonth() },
                        onNextMonth = { viewModel.nextMonth() },
                        onAddIncome = { viewModel.openAddTransactionSheet(null) },
                        onAddExpense = { viewModel.openAddTransactionSheet(null) },
                        onDailyCalculator = { viewModel.openDailyRateDialog() },
                        onLoadTemplate = { viewModel.populateStandardTemplate() },
                        onConfigureBudget = { viewModel.openBudgetSettingsDialog() },
                        onCategoryClick = { group ->
                            viewModel.updateFilter { it.copy(categoryGroup = group) }
                            viewModel.selectTab(ScreenTab.TRANSACTIONS)
                        },
                        onTransactionClick = { tx -> viewModel.openAddTransactionSheet(tx) },
                        onTogglePaid = { tx -> viewModel.togglePaidStatus(tx) },
                        onDeleteTransaction = { tx -> viewModel.deleteTransaction(tx) },
                        onNavigateToTab = { tab -> viewModel.selectTab(tab) }
                    )
                }

                ScreenTab.TRANSACTIONS -> {
                    TransactionsScreen(
                        selectedMonth = selectedMonth,
                        transactions = filteredTransactions,
                        allMonthTransactions = monthlyTransactions,
                        filterState = filterState,
                        currencySymbol = currencySymbol,
                        onPreviousMonth = { viewModel.previousMonth() },
                        onNextMonth = { viewModel.nextMonth() },
                        onUpdateFilter = { update -> viewModel.updateFilter(update) },
                        onTransactionClick = { tx -> viewModel.openAddTransactionSheet(tx) },
                        onTogglePaid = { tx -> viewModel.togglePaidStatus(tx) },
                        onDeleteTransaction = { tx -> viewModel.deleteTransaction(tx) },
                        onAddTransaction = { viewModel.openAddTransactionSheet(null) }
                    )
                }

                ScreenTab.PLANS -> {
                    PlansScreen(
                        plans = plans,
                        currentMonthKey = selectedMonth,
                        currencySymbol = currencySymbol,
                        onAddNewPlan = { viewModel.openAddPlanDialog(null) },
                        onEditPlan = { plan -> viewModel.openAddPlanDialog(plan) },
                        onDeletePlan = { plan -> viewModel.deletePlan(plan) },
                        onRecordInstallment = { plan -> viewModel.recordPlanInstallment(plan) },
                        onOpenCalculator = { viewModel.openCalculator() }
                    )
                }

                ScreenTab.ANALYTICS -> {
                    AnalyticsScreen(
                        selectedMonth = selectedMonth,
                        summary = monthlySummary,
                        budgetSettings = budgetSettings,
                        transactions = monthlyTransactions,
                        allTransactions = allTransactions,
                        currencySymbol = currencySymbol,
                        onPreviousMonth = { viewModel.previousMonth() },
                        onNextMonth = { viewModel.nextMonth() }
                    )
                }

                ScreenTab.ACCOUNTABILITY -> {
                    AccountabilityScreen(
                        rules = accountabilityRules,
                        transactions = monthlyTransactions,
                        currencySymbol = currencySymbol,
                        onAddRule = { viewModel.openAddRuleDialog() },
                        onTogglePin = { rule -> viewModel.toggleRulePin(rule) },
                        onDeleteRule = { rule -> viewModel.deleteRule(rule) },
                        onTogglePaid = { tx -> viewModel.togglePaidStatus(tx) }
                    )
                }

                ScreenTab.SYNC_SETTINGS -> {
                    SettingsSyncScreen(
                        googleAccount = googleAccount,
                        isSyncing = isSyncing,
                        lastSyncedTime = lastSyncedTime,
                        currencySymbol = currencySymbol,
                        budgetSettings = budgetSettings,
                        appTheme = appTheme,
                        isDarkTheme = isDarkTheme,
                        onSelectTheme = { theme -> viewModel.setAppTheme(theme) },
                        onToggleDarkTheme = { isDark -> viewModel.setDarkTheme(isDark) },
                        onSyncNow = { viewModel.performGoogleSync() },
                        onSetCurrency = { sym -> viewModel.setCurrency(sym) },
                        onConfigureBudget = { viewModel.openBudgetSettingsDialog() },
                        onLoadTemplate = { viewModel.populateStandardTemplate() },
                        onExportBackup = { callback -> viewModel.exportBackupJson(callback) },
                        onImportBackup = { jsonStr -> viewModel.importBackupJson(jsonStr) }
                    )
                }
            }
        }
    }

    // Modal Bottom Sheet: Add / Edit Transaction
    if (showAddSheet) {
        AddEditTransactionSheet(
            initialTransaction = editingTransaction,
            monthKey = selectedMonth,
            currencySymbol = currencySymbol,
            onDismiss = { viewModel.closeAddTransactionSheet() },
            onSave = { tx -> viewModel.saveTransaction(tx) },
            onDelete = { tx ->
                viewModel.deleteTransaction(tx)
                viewModel.closeAddTransactionSheet()
            }
        )
    }

    // Dialog: Smart Keypad Calculator
    if (showCalculatorDialog) {
        CalculatorDialog(
            initialExpression = calculatorInitialExpression,
            currencySymbol = currencySymbol,
            onDismiss = { viewModel.closeCalculator() },
            onApplyAmount = { expr, amount ->
                viewModel.closeCalculator()
                viewModel.openAddTransactionSheet(
                    com.example.data.model.TransactionEntity(
                        title = "Calculation ($expr)",
                        amount = amount,
                        expression = expr,
                        type = com.example.data.model.TransactionType.EXPENSE,
                        categoryGroup = com.example.data.model.CategoryGroup.BILLS,
                        categoryName = "General",
                        monthYearKey = selectedMonth
                    )
                )
            },
            onCreateTransaction = { amount, expr ->
                viewModel.openAddTransactionSheet(
                    com.example.data.model.TransactionEntity(
                        title = "Calculation ($expr)",
                        amount = amount,
                        expression = expr,
                        type = com.example.data.model.TransactionType.EXPENSE,
                        categoryGroup = com.example.data.model.CategoryGroup.BILLS,
                        categoryName = "General",
                        monthYearKey = selectedMonth
                    )
                )
            }
        )
    }

    // Dialog: Add / Edit Multi-Month Plan Roadmap
    if (showAddPlanDialog) {
        AddEditPlanDialog(
            initialPlan = editingPlan,
            currentMonthKey = selectedMonth,
            currencySymbol = currencySymbol,
            onDismiss = { viewModel.closeAddPlanDialog() },
            onSave = { plan -> viewModel.savePlan(plan) },
            onDelete = { plan -> viewModel.deletePlan(plan) }
        )
    }

    // Dialog: Daily Rate & Earnings Calculator
    if (showDailyRateDialog) {
        DailyRateCalculatorDialog(
            monthKey = selectedMonth,
            currencySymbol = currencySymbol,
            onDismiss = { viewModel.closeDailyRateDialog() },
            onApplyToLedger = { tx ->
                viewModel.saveTransaction(tx)
                viewModel.closeDailyRateDialog()
            }
        )
    }

    // Dialog: Add Personal Finance Rule
    if (showAddRuleDialog) {
        AddRuleDialog(
            onDismiss = { viewModel.closeAddRuleDialog() },
            onAdd = { title, content, category ->
                viewModel.addRule(title, content, category)
            }
        )
    }

    // Dialog: Configure Budget Settings (53% / 24% / 23%)
    if (showBudgetSettingsDialog) {
        BudgetSettingsDialog(
            settings = budgetSettings,
            onDismiss = { viewModel.closeBudgetSettingsDialog() },
            onSave = { bills, lifestyle, debt ->
                viewModel.saveBudgetSetting(com.example.data.model.CategoryGroup.BILLS, bills)
                viewModel.saveBudgetSetting(com.example.data.model.CategoryGroup.LIFESTYLE, lifestyle)
                viewModel.saveBudgetSetting(com.example.data.model.CategoryGroup.DEBT_AND_SAVINGS, debt)
                viewModel.closeBudgetSettingsDialog()
            }
        )
    }

    // Dialog: Google Sync info
    if (showSyncDialog) {
        GoogleSyncDialog(
            googleAccount = googleAccount,
            isSyncing = isSyncing,
            lastSyncedTime = lastSyncedTime,
            onSyncNow = { viewModel.performGoogleSync() },
            onDismiss = { viewModel.closeSyncDialog() }
        )
    }
}
