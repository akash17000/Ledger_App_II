package com.example.util

import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object ExpressionEvaluator {
    /**
     * Evaluates simple arithmetic expressions like:
     * "3500+3260" -> 6760.0
     * "39520 + (400*21)" -> 47920.0
     * "3000+(1000+1000)" -> 5000.0
     * "1200 - 500" -> 700.0
     * "5026 - 4500" -> 526.0
     */
    fun evaluate(expr: String): Double? {
        val sanitized = expr.replace(" ", "").replace(",", "").replace("৳", "").replace("$", "")
        if (sanitized.isEmpty()) return null
        return try {
            eval(sanitized)
        } catch (e: Exception) {
            sanitized.toDoubleOrNull()
        }
    }

    private fun eval(str: String): Double {
        return Parser(str).parse()
    }

    private class Parser(private val str: String) {
        private var pos = -1
        private var ch = 0

        private fun nextChar() {
            ch = if (++pos < str.length) str[pos].code else -1
        }

        private fun eat(charToEat: Int): Boolean {
            while (ch == ' '.code) nextChar()
            if (ch == charToEat) {
                nextChar()
                return true
            }
            return false
        }

        fun parse(): Double {
            nextChar()
            val result = parseExpression()
            if (pos < str.length) throw RuntimeException("Unexpected: " + ch.toChar())
            return result
        }

        private fun parseExpression(): Double {
            var x = parseTerm()
            while (true) {
                when {
                    eat('+'.code) -> x += parseTerm()
                    eat('-'.code) -> x -= parseTerm()
                    else -> return x
                }
            }
        }

        private fun parseTerm(): Double {
            var x = parseFactor()
            while (true) {
                when {
                    eat('*'.code) -> x *= parseFactor()
                    eat('/'.code) -> {
                        val divisor = parseFactor()
                        x = if (divisor != 0.0) x / divisor else 0.0
                    }
                    else -> return x
                }
            }
        }

        private fun parseFactor(): Double {
            if (eat('+'.code)) return parseFactor()
            if (eat('-'.code)) return -parseFactor()

            var x: Double
            val startPos = pos
            if (eat('('.code)) {
                x = parseExpression()
                eat(')'.code)
            } else if ((ch in '0'.code..'9'.code) || ch == '.'.code) {
                while ((ch in '0'.code..'9'.code) || ch == '.'.code) nextChar()
                x = str.substring(startPos, pos).toDouble()
            } else {
                throw RuntimeException("Unexpected: " + ch.toChar())
            }

            return x
        }
    }
}

object CurrencyFormatter {
    private val formatter = DecimalFormat("#,##0.##")
    private val currencySymbol = "৳" // Default Taka symbol matching user's note

    fun format(amount: Double, symbol: String = currencySymbol): String {
        return "$symbol ${formatter.format(amount)}"
    }

    fun formatCompact(amount: Double, symbol: String = currencySymbol): String {
        return when {
            kotlin.math.abs(amount) >= 1_000_000 -> "$symbol ${formatter.format(amount / 1_000_000)}M"
            kotlin.math.abs(amount) >= 1_000 -> "$symbol ${formatter.format(amount / 1_000)}k"
            else -> format(amount, symbol)
        }
    }
}

object DateUtils {
    private val monthYearFormat = SimpleDateFormat("yyyy-MM", Locale.getDefault())
    private val displayMonthFormat = SimpleDateFormat("MMMM yyyy", Locale.getDefault())
    private val shortDateFormat = SimpleDateFormat("dd MMM, yyyy", Locale.getDefault())
    private val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())

    fun currentMonthKey(): String = monthYearFormat.format(Date())

    fun formatDisplayMonth(monthKey: String): String {
        return try {
            val date = monthYearFormat.parse(monthKey) ?: Date()
            displayMonthFormat.format(date)
        } catch (e: Exception) {
            monthKey
        }
    }

    fun formatDate(millis: Long): String {
        return shortDateFormat.format(Date(millis))
    }

    fun formatTime(millis: Long): String {
        return timeFormat.format(Date(millis))
    }

    fun getPreviousMonth(monthKey: String): String {
        val cal = Calendar.getInstance()
        try {
            cal.time = monthYearFormat.parse(monthKey) ?: Date()
        } catch (e: Exception) {
            cal.time = Date()
        }
        cal.add(Calendar.MONTH, -1)
        return monthYearFormat.format(cal.time)
    }

    fun getNextMonth(monthKey: String): String {
        val cal = Calendar.getInstance()
        try {
            cal.time = monthYearFormat.parse(monthKey) ?: Date()
        } catch (e: Exception) {
            cal.time = Date()
        }
        cal.add(Calendar.MONTH, 1)
        return monthYearFormat.format(cal.time)
    }
}
