package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

enum class AppTheme(
    val id: String,
    val displayName: String,
    val subtitle: String,
    val primaryColor: Color,
    val secondaryColor: Color,
    val surfaceColor: Color
) {
    PIXEL(
        id = "pixel",
        displayName = "Google Pixel",
        subtitle = "Material You dynamic Monet palette with Cobalt & Sage",
        primaryColor = Color(0xFF1A73E8),
        secondaryColor = Color(0xFF1E8E3E),
        surfaceColor = Color(0xFF1D2026)
    ),
    IOS(
        id = "ios",
        displayName = "Apple iOS",
        subtitle = "Cupertino System Blue & SF Indigo with clean Zinc cards",
        primaryColor = Color(0xFF007AFF),
        secondaryColor = Color(0xFF5856D6),
        surfaceColor = Color(0xFF1C1C1E)
    ),
    EMERALD_FINTECH(
        id = "emerald",
        displayName = "Emerald Ledger",
        subtitle = "Deep forest obsidian, mint green & champagne gold",
        primaryColor = Color(0xFF10B981),
        secondaryColor = Color(0xFFFBBF24),
        surfaceColor = Color(0xFF142420)
    ),
    OLED_MIDNIGHT(
        id = "oled",
        displayName = "Midnight OLED",
        subtitle = "True pitch black with high-contrast electric neon cyan",
        primaryColor = Color(0xFF22D3EE),
        secondaryColor = Color(0xFFF472B6),
        surfaceColor = Color(0xFF0A0A0C)
    ),
    SUNSET_AMBER(
        id = "sunset",
        displayName = "Sunset & Cashmere",
        subtitle = "Warm golden amber honey, terracotta & espresso",
        primaryColor = Color(0xFFF59E0B),
        secondaryColor = Color(0xFFEA580C),
        surfaceColor = Color(0xFF261F21)
    ),
    NORDIC_GLACIER(
        id = "nordic",
        displayName = "Nordic Glacier",
        subtitle = "Crisp arctic ice blue, glacial teal & frosted navy",
        primaryColor = Color(0xFF38BDF8),
        secondaryColor = Color(0xFF2DD4BF),
        surfaceColor = Color(0xFF152230)
    )
}

// 1. Pixel Color Schemes
private val PixelDarkColorScheme = darkColorScheme(
    primary = PixelDarkPrimary,
    onPrimary = PixelDarkOnPrimary,
    primaryContainer = PixelDarkPrimaryContainer,
    onPrimaryContainer = PixelDarkOnPrimaryContainer,
    secondary = PixelDarkSecondary,
    onSecondary = PixelDarkOnSecondary,
    secondaryContainer = PixelDarkSecondaryContainer,
    onSecondaryContainer = PixelDarkOnSecondaryContainer,
    tertiary = PixelDarkTertiary,
    onTertiary = PixelDarkOnTertiary,
    tertiaryContainer = PixelDarkTertiaryContainer,
    onTertiaryContainer = PixelDarkOnTertiaryContainer,
    background = PixelDarkBackground,
    onBackground = PixelDarkOnBackground,
    surface = PixelDarkSurface,
    onSurface = PixelDarkOnSurface,
    surfaceVariant = PixelDarkSurfaceVariant,
    onSurfaceVariant = PixelDarkOnSurfaceVariant
)

private val PixelLightColorScheme = lightColorScheme(
    primary = PixelLightPrimary,
    onPrimary = PixelLightOnPrimary,
    primaryContainer = PixelLightPrimaryContainer,
    onPrimaryContainer = PixelLightOnPrimaryContainer,
    secondary = PixelLightSecondary,
    onSecondary = PixelLightOnSecondary,
    secondaryContainer = PixelLightSecondaryContainer,
    onSecondaryContainer = PixelLightOnSecondaryContainer,
    tertiary = PixelLightTertiary,
    onTertiary = PixelLightOnTertiary,
    tertiaryContainer = PixelLightTertiaryContainer,
    onTertiaryContainer = PixelLightOnTertiaryContainer,
    background = PixelLightBackground,
    onBackground = PixelLightOnBackground,
    surface = PixelLightSurface,
    onSurface = PixelLightOnSurface,
    surfaceVariant = PixelLightSurfaceVariant,
    onSurfaceVariant = PixelLightOnSurfaceVariant
)

// 2. iOS Cupertino Color Schemes
private val IosDarkColorScheme = darkColorScheme(
    primary = IosDarkPrimary,
    onPrimary = IosDarkOnPrimary,
    primaryContainer = IosDarkPrimaryContainer,
    onPrimaryContainer = IosDarkOnPrimaryContainer,
    secondary = IosDarkSecondary,
    onSecondary = IosDarkOnSecondary,
    secondaryContainer = IosDarkSecondaryContainer,
    onSecondaryContainer = IosDarkOnSecondaryContainer,
    tertiary = IosDarkTertiary,
    onTertiary = IosDarkOnTertiary,
    tertiaryContainer = IosDarkTertiaryContainer,
    onTertiaryContainer = IosDarkOnTertiaryContainer,
    background = IosDarkBackground,
    onBackground = IosDarkOnBackground,
    surface = IosDarkSurface,
    onSurface = IosDarkOnSurface,
    surfaceVariant = IosDarkSurfaceVariant,
    onSurfaceVariant = IosDarkOnSurfaceVariant
)

private val IosLightColorScheme = lightColorScheme(
    primary = IosLightPrimary,
    onPrimary = IosLightOnPrimary,
    primaryContainer = IosLightPrimaryContainer,
    onPrimaryContainer = IosLightOnPrimaryContainer,
    secondary = IosLightSecondary,
    onSecondary = IosLightOnSecondary,
    secondaryContainer = IosLightSecondaryContainer,
    onSecondaryContainer = IosLightOnSecondaryContainer,
    tertiary = IosLightTertiary,
    onTertiary = IosLightOnTertiary,
    tertiaryContainer = IosLightTertiaryContainer,
    onTertiaryContainer = IosLightOnTertiaryContainer,
    background = IosLightBackground,
    onBackground = IosLightOnBackground,
    surface = IosLightSurface,
    onSurface = IosLightOnSurface,
    surfaceVariant = IosLightSurfaceVariant,
    onSurfaceVariant = IosLightOnSurfaceVariant
)

// 3. Emerald Obsidian Color Schemes
private val EmeraldDarkColorScheme = darkColorScheme(
    primary = EmeraldDarkPrimary,
    onPrimary = EmeraldDarkOnPrimary,
    primaryContainer = EmeraldDarkPrimaryContainer,
    onPrimaryContainer = EmeraldDarkOnPrimaryContainer,
    secondary = EmeraldDarkSecondary,
    onSecondary = EmeraldDarkOnSecondary,
    secondaryContainer = EmeraldDarkSecondaryContainer,
    onSecondaryContainer = EmeraldDarkOnSecondaryContainer,
    tertiary = EmeraldDarkTertiary,
    onTertiary = EmeraldDarkOnTertiary,
    tertiaryContainer = EmeraldDarkTertiaryContainer,
    onTertiaryContainer = EmeraldDarkOnTertiaryContainer,
    background = EmeraldDarkBackground,
    onBackground = EmeraldDarkOnBackground,
    surface = EmeraldDarkSurface,
    onSurface = EmeraldDarkOnSurface,
    surfaceVariant = EmeraldDarkSurfaceVariant,
    onSurfaceVariant = EmeraldDarkOnSurfaceVariant
)

private val EmeraldLightColorScheme = lightColorScheme(
    primary = EmeraldLightPrimary,
    onPrimary = EmeraldLightOnPrimary,
    primaryContainer = EmeraldLightPrimaryContainer,
    onPrimaryContainer = EmeraldLightOnPrimaryContainer,
    secondary = EmeraldLightSecondary,
    onSecondary = EmeraldLightOnSecondary,
    secondaryContainer = EmeraldLightSecondaryContainer,
    onSecondaryContainer = EmeraldLightOnSecondaryContainer,
    tertiary = EmeraldLightTertiary,
    onTertiary = EmeraldLightOnTertiary,
    tertiaryContainer = EmeraldLightTertiaryContainer,
    onTertiaryContainer = EmeraldLightOnTertiaryContainer,
    background = EmeraldLightBackground,
    onBackground = EmeraldLightOnBackground,
    surface = EmeraldLightSurface,
    onSurface = EmeraldLightOnSurface,
    surfaceVariant = EmeraldLightSurfaceVariant,
    onSurfaceVariant = EmeraldLightOnSurfaceVariant
)

// 4. OLED Midnight Color Schemes
private val OledDarkColorScheme = darkColorScheme(
    primary = OledDarkPrimary,
    onPrimary = OledDarkOnPrimary,
    primaryContainer = OledDarkPrimaryContainer,
    onPrimaryContainer = OledDarkOnPrimaryContainer,
    secondary = OledDarkSecondary,
    onSecondary = OledDarkOnSecondary,
    secondaryContainer = OledDarkSecondaryContainer,
    onSecondaryContainer = OledDarkOnSecondaryContainer,
    tertiary = OledDarkTertiary,
    onTertiary = OledDarkOnTertiary,
    tertiaryContainer = OledDarkTertiaryContainer,
    onTertiaryContainer = OledDarkOnTertiaryContainer,
    background = OledDarkBackground,
    onBackground = OledDarkOnBackground,
    surface = OledDarkSurface,
    onSurface = OledDarkOnSurface,
    surfaceVariant = OledDarkSurfaceVariant,
    onSurfaceVariant = OledDarkOnSurfaceVariant
)

private val OledLightColorScheme = lightColorScheme(
    primary = OledLightPrimary,
    onPrimary = OledLightOnPrimary,
    primaryContainer = OledLightPrimaryContainer,
    onPrimaryContainer = OledLightOnPrimaryContainer,
    secondary = OledLightSecondary,
    onSecondary = OledLightOnSecondary,
    secondaryContainer = OledLightSecondaryContainer,
    onSecondaryContainer = OledLightOnSecondaryContainer,
    tertiary = OledLightTertiary,
    onTertiary = OledLightOnTertiary,
    tertiaryContainer = OledLightTertiaryContainer,
    onTertiaryContainer = OledLightOnTertiaryContainer,
    background = OledLightBackground,
    onBackground = OledLightOnBackground,
    surface = OledLightSurface,
    onSurface = OledLightOnSurface,
    surfaceVariant = OledLightSurfaceVariant,
    onSurfaceVariant = OledLightOnSurfaceVariant
)

// 5. Sunset Gold Color Schemes
private val SunsetDarkColorScheme = darkColorScheme(
    primary = SunsetDarkPrimary,
    onPrimary = SunsetDarkOnPrimary,
    primaryContainer = SunsetDarkPrimaryContainer,
    onPrimaryContainer = SunsetDarkOnPrimaryContainer,
    secondary = SunsetDarkSecondary,
    onSecondary = SunsetDarkOnSecondary,
    secondaryContainer = SunsetDarkSecondaryContainer,
    onSecondaryContainer = SunsetDarkOnSecondaryContainer,
    tertiary = SunsetDarkTertiary,
    onTertiary = SunsetDarkOnTertiary,
    tertiaryContainer = SunsetDarkTertiaryContainer,
    onTertiaryContainer = SunsetDarkOnTertiaryContainer,
    background = SunsetDarkBackground,
    onBackground = SunsetDarkOnBackground,
    surface = SunsetDarkSurface,
    onSurface = SunsetDarkOnSurface,
    surfaceVariant = SunsetDarkSurfaceVariant,
    onSurfaceVariant = SunsetDarkOnSurfaceVariant
)

private val SunsetLightColorScheme = lightColorScheme(
    primary = SunsetLightPrimary,
    onPrimary = SunsetLightOnPrimary,
    primaryContainer = SunsetLightPrimaryContainer,
    onPrimaryContainer = SunsetLightOnPrimaryContainer,
    secondary = SunsetLightSecondary,
    onSecondary = SunsetLightOnSecondary,
    secondaryContainer = SunsetLightSecondaryContainer,
    onSecondaryContainer = SunsetLightOnSecondaryContainer,
    tertiary = SunsetLightTertiary,
    onTertiary = SunsetLightOnTertiary,
    tertiaryContainer = SunsetLightTertiaryContainer,
    onTertiaryContainer = SunsetLightOnTertiaryContainer,
    background = SunsetLightBackground,
    onBackground = SunsetLightOnBackground,
    surface = SunsetLightSurface,
    onSurface = SunsetLightOnSurface,
    surfaceVariant = SunsetLightSurfaceVariant,
    onSurfaceVariant = SunsetLightOnSurfaceVariant
)

// 6. Nordic Glacier Color Schemes
private val NordicDarkColorScheme = darkColorScheme(
    primary = NordicDarkPrimary,
    onPrimary = NordicDarkOnPrimary,
    primaryContainer = NordicDarkPrimaryContainer,
    onPrimaryContainer = NordicDarkOnPrimaryContainer,
    secondary = NordicDarkSecondary,
    onSecondary = NordicDarkOnSecondary,
    secondaryContainer = NordicDarkSecondaryContainer,
    onSecondaryContainer = NordicDarkOnSecondaryContainer,
    tertiary = NordicDarkTertiary,
    onTertiary = NordicDarkOnTertiary,
    tertiaryContainer = NordicDarkTertiaryContainer,
    onTertiaryContainer = NordicDarkOnTertiaryContainer,
    background = NordicDarkBackground,
    onBackground = NordicDarkOnBackground,
    surface = NordicDarkSurface,
    onSurface = NordicDarkOnSurface,
    surfaceVariant = NordicDarkSurfaceVariant,
    onSurfaceVariant = NordicDarkOnSurfaceVariant
)

private val NordicLightColorScheme = lightColorScheme(
    primary = NordicLightPrimary,
    onPrimary = NordicLightOnPrimary,
    primaryContainer = NordicLightPrimaryContainer,
    onPrimaryContainer = NordicLightOnPrimaryContainer,
    secondary = NordicLightSecondary,
    onSecondary = NordicLightOnSecondary,
    secondaryContainer = NordicLightSecondaryContainer,
    onSecondaryContainer = NordicLightOnSecondaryContainer,
    tertiary = NordicLightTertiary,
    onTertiary = NordicLightOnTertiary,
    tertiaryContainer = NordicLightTertiaryContainer,
    onTertiaryContainer = NordicLightOnTertiaryContainer,
    background = NordicLightBackground,
    onBackground = NordicLightOnBackground,
    surface = NordicLightSurface,
    onSurface = NordicLightOnSurface,
    surfaceVariant = NordicLightSurfaceVariant,
    onSurfaceVariant = NordicLightOnSurfaceVariant
)

@Composable
fun LedgerTrackTheme(
    appTheme: AppTheme = AppTheme.PIXEL,
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val colorScheme: ColorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        else -> when (appTheme) {
            AppTheme.PIXEL -> if (darkTheme) PixelDarkColorScheme else PixelLightColorScheme
            AppTheme.IOS -> if (darkTheme) IosDarkColorScheme else IosLightColorScheme
            AppTheme.EMERALD_FINTECH -> if (darkTheme) EmeraldDarkColorScheme else EmeraldLightColorScheme
            AppTheme.OLED_MIDNIGHT -> if (darkTheme) OledDarkColorScheme else OledLightColorScheme
            AppTheme.SUNSET_AMBER -> if (darkTheme) SunsetDarkColorScheme else SunsetLightColorScheme
            AppTheme.NORDIC_GLACIER -> if (darkTheme) NordicDarkColorScheme else NordicLightColorScheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}


