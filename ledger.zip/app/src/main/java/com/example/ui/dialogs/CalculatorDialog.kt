package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.CurrencyFormatter
import com.example.util.ExpressionEvaluator

@Composable
fun CalculatorDialog(
    initialExpression: String = "",
    currencySymbol: String = "৳",
    onDismiss: () -> Unit,
    onApplyAmount: (expression: String, evaluatedValue: Double) -> Unit,
    onCreateTransaction: ((amount: Double, expression: String) -> Unit)? = null
) {
    val clipboardManager = LocalClipboardManager.current
    var expression by remember { mutableStateOf(initialExpression) }
    var history by remember { mutableStateOf<List<Pair<String, Double>>>(emptyList()) }

    val liveResult = remember(expression) {
        if (expression.isBlank()) null else ExpressionEvaluator.evaluate(expression)
    }

    val quickFormulas = listOf(
        "400*21" to "Daily Rate (21 days @ 400)",
        "3500+3260" to "Home & Support Split",
        "3000+2000" to "Savings & Buffer",
        "1200-500" to "Partial Paid Deduction",
        "5000+5000" to "Debt 1 + Debt 2",
        "1000+231" to "DPS 1 + DPS 2"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth(0.96f),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Calculate,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "Smart Calculator",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Fast input & equation solver",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Calculator Display Screen
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalAlignment = Alignment.End,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // Current Expression Line
                        Text(
                            text = if (expression.isEmpty()) "0" else expression,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 18.sp,
                                letterSpacing = 0.5.sp
                            ),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2,
                            textAlign = TextAlign.End
                        )

                        // Live Result Line
                        Text(
                            text = if (liveResult != null) {
                                "= ${CurrencyFormatter.format(liveResult, currencySymbol)}"
                            } else if (expression.isNotBlank()) {
                                "..."
                            } else {
                                "= 0 $currencySymbol"
                            },
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 26.sp
                            ),
                            color = MaterialTheme.colorScheme.primary,
                            textAlign = TextAlign.End
                        )
                    }
                }

                // Quick Calculation Presets
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    quickFormulas.forEach { (formula, label) ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickable {
                                    expression = formula
                                }
                        ) {
                            Text(
                                text = formula,
                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                            )
                        }
                    }
                }

                // Interactive Calculator Keypad Grid
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Row 1: C, (, ), /
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        CalcButton(
                            text = "C",
                            modifier = Modifier.weight(1f),
                            color = MaterialTheme.colorScheme.error,
                            containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f),
                            onClick = { expression = "" }
                        )
                        CalcButton(
                            text = "(",
                            modifier = Modifier.weight(1f),
                            onClick = { expression += "(" }
                        )
                        CalcButton(
                            text = ")",
                            modifier = Modifier.weight(1f),
                            onClick = { expression += ")" }
                        )
                        CalcButton(
                            text = "÷",
                            modifier = Modifier.weight(1f),
                            color = MaterialTheme.colorScheme.primary,
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                            onClick = { expression += "/" }
                        )
                    }

                    // Row 2: 7, 8, 9, *
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        CalcButton(text = "7", modifier = Modifier.weight(1f), onClick = { expression += "7" })
                        CalcButton(text = "8", modifier = Modifier.weight(1f), onClick = { expression += "8" })
                        CalcButton(text = "9", modifier = Modifier.weight(1f), onClick = { expression += "9" })
                        CalcButton(
                            text = "×",
                            modifier = Modifier.weight(1f),
                            color = MaterialTheme.colorScheme.primary,
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                            onClick = { expression += "*" }
                        )
                    }

                    // Row 3: 4, 5, 6, -
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        CalcButton(text = "4", modifier = Modifier.weight(1f), onClick = { expression += "4" })
                        CalcButton(text = "5", modifier = Modifier.weight(1f), onClick = { expression += "5" })
                        CalcButton(text = "6", modifier = Modifier.weight(1f), onClick = { expression += "6" })
                        CalcButton(
                            text = "-",
                            modifier = Modifier.weight(1f),
                            color = MaterialTheme.colorScheme.primary,
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                            onClick = { expression += "-" }
                        )
                    }

                    // Row 4: 1, 2, 3, +
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        CalcButton(text = "1", modifier = Modifier.weight(1f), onClick = { expression += "1" })
                        CalcButton(text = "2", modifier = Modifier.weight(1f), onClick = { expression += "2" })
                        CalcButton(text = "3", modifier = Modifier.weight(1f), onClick = { expression += "3" })
                        CalcButton(
                            text = "+",
                            modifier = Modifier.weight(1f),
                            color = MaterialTheme.colorScheme.primary,
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                            onClick = { expression += "+" }
                        )
                    }

                    // Row 5: 0, ., ⌫, =
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        CalcButton(text = "0", modifier = Modifier.weight(1f), onClick = { expression += "0" })
                        CalcButton(text = ".", modifier = Modifier.weight(1f), onClick = { expression += "." })
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .clickable {
                                    if (expression.isNotEmpty()) {
                                        expression = expression.dropLast(1)
                                    }
                                },
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Backspace,
                                    contentDescription = "Backspace",
                                    tint = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        CalcButton(
                            text = "=",
                            modifier = Modifier.weight(1f),
                            color = MaterialTheme.colorScheme.onPrimary,
                            containerColor = MaterialTheme.colorScheme.primary,
                            onClick = {
                                if (liveResult != null) {
                                    val evaluated = liveResult
                                    val formatted = if (evaluated % 1.0 == 0.0) evaluated.toLong().toString() else evaluated.toString()
                                    history = listOf(expression to evaluated) + history.take(4)
                                    expression = formatted
                                }
                            }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val finalVal = liveResult ?: (expression.toDoubleOrNull() ?: 0.0)
                    onApplyAmount(expression, finalVal)
                },
                modifier = Modifier.testTag("apply_calculator_result_btn")
            ) {
                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Apply to Amount")
            }
        },
        dismissButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (onCreateTransaction != null && liveResult != null && liveResult > 0) {
                    OutlinedButton(
                        onClick = {
                            onCreateTransaction(liveResult, expression)
                            onDismiss()
                        }
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Tx")
                    }
                }
                OutlinedButton(
                    onClick = {
                        val toCopy = (liveResult ?: (expression.toDoubleOrNull() ?: 0.0)).toString()
                        clipboardManager.setText(AnnotatedString(toCopy))
                        onDismiss()
                    }
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                }
            }
        }
    )
}

@Composable
private fun CalcButton(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.onSurface,
    containerColor: Color = MaterialTheme.colorScheme.surfaceVariant,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .height(46.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        color = containerColor
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = text,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 18.sp
                ),
                color = color
            )
        }
    }
}
