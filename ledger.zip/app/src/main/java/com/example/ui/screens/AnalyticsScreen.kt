package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults.SecondaryIndicator
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BudgetSettingEntity
import com.example.data.model.CategoryGroup
import com.example.data.model.MonthlySummary
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.ui.components.CategoryDonutChart
import com.example.ui.components.MonthPickerHeader
import com.example.ui.components.MonthlyIncomeExpenseComparison
import com.example.ui.components.PaymentAccountBreakdown
import com.example.ui.components.TimeFrameComparisonView
import com.example.ui.theme.BillsColor
import com.example.ui.theme.DebtSavingsColor
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.LifestyleColor
import com.example.util.CurrencyFormatter

@Composable
fun AnalyticsScreen(
    selectedMonth: String,
    summary: MonthlySummary,
    budgetSettings: List<BudgetSettingEntity>,
    transactions: List<TransactionEntity>,
    allTransactions: List<TransactionEntity> = transactions,
    currencySymbol: String,
    onPreviousMonth: () -> Unit,
    onNextMonth: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedAnalysisMode by remember { mutableIntStateOf(0) } // 0: Single Month, 1: Compare Timeframes

    val billsTarget = budgetSettings.find { it.groupType == CategoryGroup.BILLS }?.targetPercentage ?: 53f
    val lifestyleTarget = budgetSettings.find { it.groupType == CategoryGroup.LIFESTYLE }?.targetPercentage ?: 24f
    val debtTarget = budgetSettings.find { it.groupType == CategoryGroup.DEBT_AND_SAVINGS }?.targetPercentage ?: 23f

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Mode Selector: Single Month vs Time Frame Comparison
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    // Tab 0: Single Month
                    val isTab0 = selectedAnalysisMode == 0
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isTab0) MaterialTheme.colorScheme.primary else Color.Transparent)
                            .clickable { selectedAnalysisMode = 0 }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.BarChart,
                                contentDescription = null,
                                tint = if (isTab0) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "Monthly Deep Dive",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (isTab0) FontWeight.Bold else FontWeight.Medium,
                                color = if (isTab0) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // Tab 1: Compare Timeframes
                    val isTab1 = selectedAnalysisMode == 1
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isTab1) MaterialTheme.colorScheme.primary else Color.Transparent)
                            .clickable { selectedAnalysisMode = 1 }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CompareArrows,
                                contentDescription = null,
                                tint = if (isTab1) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "Compare Timeframes",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (isTab1) FontWeight.Bold else FontWeight.Medium,
                                color = if (isTab1) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        if (selectedAnalysisMode == 1) {
            // Time Frame Comparison View
            item {
                TimeFrameComparisonView(
                    allTransactions = allTransactions,
                    currentMonthKey = selectedMonth,
                    currencySymbol = currencySymbol
                )
            }
        } else {
            // Single Month Analytics
            // Month Picker Bar
            item {
                MonthPickerHeader(
                    selectedMonth = selectedMonth,
                    onPreviousMonth = onPreviousMonth,
                    onNextMonth = onNextMonth
                )
            }

            // Donut Chart
            item {
                CategoryDonutChart(
                    summary = summary,
                    currencySymbol = currencySymbol
                )
            }

            // Income vs Expense comparison
            item {
                MonthlyIncomeExpenseComparison(
                    summary = summary,
                    currencySymbol = currencySymbol
                )
            }

            // Target vs Actual Allocation Matrix Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Budget Allocation Matrix",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        // Header
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Category", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Target %", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Actual %", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Amount", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }

                        // Bills Row
                        BudgetMatrixRow(
                            name = "1. Bills",
                            targetPercent = billsTarget,
                            actualPercent = summary.billsPercentage,
                            amount = summary.billsTotal,
                            color = BillsColor,
                            currencySymbol = currencySymbol
                        )

                        // Lifestyle Row
                        BudgetMatrixRow(
                            name = "2. Life Style",
                            targetPercent = lifestyleTarget,
                            actualPercent = summary.lifestylePercentage,
                            amount = summary.lifestyleTotal,
                            color = LifestyleColor,
                            currencySymbol = currencySymbol
                        )

                        // Debt Row
                        BudgetMatrixRow(
                            name = "3. Debt & Savings",
                            targetPercent = debtTarget,
                            actualPercent = summary.debtSavingsPercentage,
                            amount = summary.debtAndSavingsTotal,
                            color = DebtSavingsColor,
                            currencySymbol = currencySymbol
                        )
                    }
                }
            }

            // Planned vs Actual Variance Inspection Card
            val varianceExpenses = transactions.filter { it.type == TransactionType.EXPENSE && it.plannedAmount != null }
            if (varianceExpenses.isNotEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "Planned vs Actual Expense Variance",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )

                            varianceExpenses.forEach { item ->
                                val plan = item.plannedAmount ?: 0.0
                                val diff = item.amount - plan
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(item.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                        Text("Plan: ${CurrencyFormatter.format(plan, currencySymbol)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("Actual: ${CurrencyFormatter.format(item.amount, currencySymbol)}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                        Text(
                                            text = "${if (diff > 0) "+" else ""}${CurrencyFormatter.format(diff, currencySymbol)}",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = if (diff > 0) MaterialTheme.colorScheme.error else IncomeGreen
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Payment Method Distribution
            item {
                PaymentAccountBreakdown(
                    transactions = transactions,
                    currencySymbol = currencySymbol
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}


@Composable
fun BudgetMatrixRow(
    name: String,
    targetPercent: Float,
    actualPercent: Float,
    amount: Double,
    color: androidx.compose.ui.graphics.Color,
    currencySymbol: String
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = color.copy(alpha = 0.08f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(name, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = color)
            Text("${targetPercent.toInt()}%", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                "${"%.1f".format(actualPercent)}%",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                color = if (actualPercent > targetPercent + 2f) MaterialTheme.colorScheme.error else color
            )
            Text(CurrencyFormatter.formatCompact(amount, currencySymbol), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
        }
    }
}
