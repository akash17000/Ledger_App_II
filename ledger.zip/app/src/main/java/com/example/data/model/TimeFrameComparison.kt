package com.example.data.model

import com.example.util.DateUtils
import java.util.Calendar
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.Date

enum class ComparisonPreset(
    val title: String,
    val subtitle: String
) {
    MONTH_OVER_MONTH("Month vs Previous", "Compare current month against prior month"),
    LAST_3_MONTHS("3-Month vs Prior 3M", "Compare past 3 months against previous 3 months"),
    QUARTER_OVER_QUARTER("Quarter vs Prior", "Compare current quarter against previous quarter"),
    LAST_6_MONTHS("6-Month vs Prior 6M", "Compare past 6 months against previous 6 months"),
    YEARLY("Yearly Comparison", "Compare current year vs previous year"),
    CUSTOM("Custom Pick", "Choose any two custom periods or months")
}

data class MonthlyTrendPoint(
    val monthKey: String,
    val displayLabel: String,
    val income: Double,
    val expense: Double,
    val netSavings: Double
)

data class PeriodStats(
    val label: String,
    val monthKeys: List<String>,
    val totalIncome: Double,
    val totalExpenses: Double,
    val netSavings: Double,
    val savingsRate: Float,
    val billsTotal: Double,
    val billsPercentage: Float,
    val lifestyleTotal: Double,
    val lifestylePercentage: Float,
    val debtSavingsTotal: Double,
    val debtSavingsPercentage: Float,
    val monthlyBreakdown: List<MonthlyTrendPoint>,
    val categoryTotals: Map<String, Double>,
    val transactionCount: Int
)

data class CategoryComparisonDelta(
    val categoryName: String,
    val group: CategoryGroup,
    val period1Amount: Double,
    val period2Amount: Double,
    val deltaAmount: Double,
    val deltaPercent: Float
)

data class TimeFrameComparisonResult(
    val preset: ComparisonPreset,
    val period1: PeriodStats, // Focus / Recent
    val period2: PeriodStats, // Baseline / Previous
    val incomeDeltaAmount: Double,
    val incomeDeltaPercent: Float,
    val expenseDeltaAmount: Double,
    val expenseDeltaPercent: Float,
    val netSavingsDeltaAmount: Double,
    val netSavingsDeltaPercent: Float,
    val savingsRateDelta: Float,
    val categoryDeltas: List<CategoryComparisonDelta>
)

object TimeFrameCalculator {

    fun generatePresetPeriods(
        preset: ComparisonPreset,
        currentMonthKey: String
    ): Pair<Pair<String, List<String>>, Pair<String, List<String>>> {
        val sdf = SimpleDateFormat("yyyy-MM", Locale.getDefault())
        val cal = Calendar.getInstance()
        try {
            cal.time = sdf.parse(currentMonthKey) ?: Date()
        } catch (e: Exception) {
            cal.time = Date()
        }

        return when (preset) {
            ComparisonPreset.MONTH_OVER_MONTH -> {
                val p1Keys = listOf(currentMonthKey)
                val prevMonthKey = DateUtils.getPreviousMonth(currentMonthKey)
                val p2Keys = listOf(prevMonthKey)
                val p1Label = DateUtils.formatDisplayMonth(currentMonthKey)
                val p2Label = DateUtils.formatDisplayMonth(prevMonthKey)
                Pair(Pair(p1Label, p1Keys), Pair(p2Label, p2Keys))
            }
            ComparisonPreset.LAST_3_MONTHS -> {
                val p1Months = getOffsetMonthKeys(currentMonthKey, 0, 3)
                val p2Months = getOffsetMonthKeys(currentMonthKey, 3, 3)
                val p1Label = "Recent 3 Months (${DateUtils.formatDisplayMonth(p1Months.last()).substring(0, 3)} - ${DateUtils.formatDisplayMonth(p1Months.first()).substring(0, 3)})"
                val p2Label = "Prior 3 Months (${DateUtils.formatDisplayMonth(p2Months.last()).substring(0, 3)} - ${DateUtils.formatDisplayMonth(p2Months.first()).substring(0, 3)})"
                Pair(Pair(p1Label, p1Months), Pair(p2Label, p2Months))
            }
            ComparisonPreset.QUARTER_OVER_QUARTER -> {
                val year = currentMonthKey.substringBefore("-").toIntOrNull() ?: 2026
                val month = currentMonthKey.substringAfter("-").toIntOrNull() ?: 8
                val currentQuarter = (month - 1) / 3 + 1
                val p1Months = when (currentQuarter) {
                    1 -> listOf("$year-01", "$year-02", "$year-03")
                    2 -> listOf("$year-04", "$year-05", "$year-06")
                    3 -> listOf("$year-07", "$year-08", "$year-09")
                    else -> listOf("$year-10", "$year-11", "$year-12")
                }
                val (prevYear, prevQuarter) = if (currentQuarter == 1) Pair(year - 1, 4) else Pair(year, currentQuarter - 1)
                val p2Months = when (prevQuarter) {
                    1 -> listOf("$prevYear-01", "$prevYear-02", "$prevYear-03")
                    2 -> listOf("$prevYear-04", "$prevYear-05", "$prevYear-06")
                    3 -> listOf("$prevYear-07", "$prevYear-08", "$prevYear-09")
                    else -> listOf("$prevYear-10", "$prevYear-11", "$prevYear-12")
                }
                Pair(Pair("Q$currentQuarter $year", p1Months), Pair("Q$prevQuarter $prevYear", p2Months))
            }
            ComparisonPreset.LAST_6_MONTHS -> {
                val p1Months = getOffsetMonthKeys(currentMonthKey, 0, 6)
                val p2Months = getOffsetMonthKeys(currentMonthKey, 6, 6)
                val p1Label = "Last 6 Months"
                val p2Label = "Prior 6 Months"
                Pair(Pair(p1Label, p1Months), Pair(p2Label, p2Months))
            }
            ComparisonPreset.YEARLY -> {
                val year = currentMonthKey.substringBefore("-").toIntOrNull() ?: 2026
                val prevYear = year - 1
                val p1Months = (1..12).map { "$year-${it.toString().padStart(2, '0')}" }
                val p2Months = (1..12).map { "$prevYear-${it.toString().padStart(2, '0')}" }
                Pair(Pair("Year $year", p1Months), Pair("Year $prevYear", p2Months))
            }
            ComparisonPreset.CUSTOM -> {
                val p1Keys = listOf(currentMonthKey)
                val prevMonthKey = DateUtils.getPreviousMonth(currentMonthKey)
                val p2Keys = listOf(prevMonthKey)
                Pair(Pair(DateUtils.formatDisplayMonth(currentMonthKey), p1Keys), Pair(DateUtils.formatDisplayMonth(prevMonthKey), p2Keys))
            }
        }
    }

    private fun getOffsetMonthKeys(startMonthKey: String, offsetMonths: Int, count: Int): List<String> {
        val sdf = SimpleDateFormat("yyyy-MM", Locale.getDefault())
        val cal = Calendar.getInstance()
        try {
            cal.time = sdf.parse(startMonthKey) ?: Date()
        } catch (e: Exception) {
            cal.time = Date()
        }
        cal.add(Calendar.MONTH, -offsetMonths)

        val result = mutableListOf<String>()
        for (i in 0 until count) {
            result.add(sdf.format(cal.time))
            cal.add(Calendar.MONTH, -1)
        }
        return result
    }

    fun computePeriodStats(
        label: String,
        monthKeys: List<String>,
        allTransactions: List<TransactionEntity>
    ): PeriodStats {
        val periodTransactions = allTransactions.filter { it.monthYearKey in monthKeys }

        var income = 0.0
        var expense = 0.0
        var bills = 0.0
        var lifestyle = 0.0
        var debtSavings = 0.0

        val categoryMap = mutableMapOf<String, Double>()

        periodTransactions.forEach { tx ->
            if (tx.type == TransactionType.INCOME) {
                income += tx.amount
            } else {
                expense += tx.amount
                when (tx.categoryGroup) {
                    CategoryGroup.BILLS -> bills += tx.amount
                    CategoryGroup.LIFESTYLE -> lifestyle += tx.amount
                    CategoryGroup.DEBT_AND_SAVINGS -> debtSavings += tx.amount
                    else -> {}
                }
                val catKey = tx.categoryName
                categoryMap[catKey] = (categoryMap[catKey] ?: 0.0) + tx.amount
            }
        }

        val netSavings = income - expense
        val savingsRate = if (income > 0) ((netSavings / income) * 100f).toFloat().coerceIn(-100f, 100f) else 0f

        val billsPercent = if (expense > 0) ((bills / expense) * 100f).toFloat() else 0f
        val lifestylePercent = if (expense > 0) ((lifestyle / expense) * 100f).toFloat() else 0f
        val debtSavingsPercent = if (expense > 0) ((debtSavings / expense) * 100f).toFloat() else 0f

        // Monthly trend points
        val monthlyPoints = monthKeys.sorted().map { mKey ->
            val mTx = periodTransactions.filter { it.monthYearKey == mKey }
            val mInc = mTx.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
            val mExp = mTx.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
            val mLabel = try {
                val sdf = SimpleDateFormat("yyyy-MM", Locale.getDefault())
                val outSdf = SimpleDateFormat("MMM yy", Locale.getDefault())
                val d = sdf.parse(mKey) ?: Date()
                outSdf.format(d)
            } catch (e: Exception) {
                mKey
            }
            MonthlyTrendPoint(mKey, mLabel, mInc, mExp, mInc - mExp)
        }

        return PeriodStats(
            label = label,
            monthKeys = monthKeys,
            totalIncome = income,
            totalExpenses = expense,
            netSavings = netSavings,
            savingsRate = savingsRate,
            billsTotal = bills,
            billsPercentage = billsPercent,
            lifestyleTotal = lifestyle,
            lifestylePercentage = lifestylePercent,
            debtSavingsTotal = debtSavings,
            debtSavingsPercentage = debtSavingsPercent,
            monthlyBreakdown = monthlyPoints,
            categoryTotals = categoryMap,
            transactionCount = periodTransactions.size
        )
    }

    fun comparePeriods(
        preset: ComparisonPreset,
        period1: PeriodStats,
        period2: PeriodStats,
        allTransactions: List<TransactionEntity>
    ): TimeFrameComparisonResult {
        val incomeDeltaAmount = period1.totalIncome - period2.totalIncome
        val incomeDeltaPercent = if (period2.totalIncome > 0) {
            ((incomeDeltaAmount / period2.totalIncome) * 100f).toFloat()
        } else if (period1.totalIncome > 0) 100f else 0f

        val expenseDeltaAmount = period1.totalExpenses - period2.totalExpenses
        val expenseDeltaPercent = if (period2.totalExpenses > 0) {
            ((expenseDeltaAmount / period2.totalExpenses) * 100f).toFloat()
        } else if (period1.totalExpenses > 0) 100f else 0f

        val netSavingsDeltaAmount = period1.netSavings - period2.netSavings
        val netSavingsDeltaPercent = if (period2.netSavings != 0.0) {
            ((netSavingsDeltaAmount / kotlin.math.abs(period2.netSavings)) * 100f).toFloat()
        } else 0f

        val savingsRateDelta = period1.savingsRate - period2.savingsRate

        // Compare categories
        val allCatNames = (period1.categoryTotals.keys + period2.categoryTotals.keys).distinct()
        val catDeltas = allCatNames.map { name ->
            val p1Amt = period1.categoryTotals[name] ?: 0.0
            val p2Amt = period2.categoryTotals[name] ?: 0.0
            val diff = p1Amt - p2Amt
            val pct = if (p2Amt > 0) ((diff / p2Amt) * 100f).toFloat() else if (p1Amt > 0) 100f else 0f
            val sampleTx = allTransactions.firstOrNull { it.categoryName == name }
            val group = sampleTx?.categoryGroup ?: CategoryGroup.LIFESTYLE
            CategoryComparisonDelta(
                categoryName = name,
                group = group,
                period1Amount = p1Amt,
                period2Amount = p2Amt,
                deltaAmount = diff,
                deltaPercent = pct
            )
        }.sortedByDescending { kotlin.math.abs(it.deltaAmount) }

        return TimeFrameComparisonResult(
            preset = preset,
            period1 = period1,
            period2 = period2,
            incomeDeltaAmount = incomeDeltaAmount,
            incomeDeltaPercent = incomeDeltaPercent,
            expenseDeltaAmount = expenseDeltaAmount,
            expenseDeltaPercent = expenseDeltaPercent,
            netSavingsDeltaAmount = netSavingsDeltaAmount,
            netSavingsDeltaPercent = netSavingsDeltaPercent,
            savingsRateDelta = savingsRateDelta,
            categoryDeltas = catDeltas
        )
    }
}
