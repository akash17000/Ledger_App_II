package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TransactionType {
    INCOME,
    EXPENSE
}

enum class CategoryGroup(val displayName: String, val defaultTargetPercent: Float) {
    BILLS("Bills", 53f),
    LIFESTYLE("Life Style", 24f),
    DEBT_AND_SAVINGS("Debt & Savings", 23f),
    INCOME_BASE("Base Income", 0f),
    INCOME_EXTRA("Extra Income", 0f),
    OTHER("Other", 0f);

    companion object {
        fun fromString(value: String): CategoryGroup {
            return entries.firstOrNull { it.name.equals(value, ignoreCase = true) || it.displayName.equals(value, ignoreCase = true) }
                ?: OTHER
        }
    }
}

enum class PlanType(val displayName: String) {
    DEBT_REPAYMENT("Debt Repayment"),
    SAVINGS_GOAL("Savings Goal"),
    INVESTMENT_DPS("DPS & Recurring"),
    FUTURE_EXPENSE("Future Expense")
}

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val amount: Double,
    val expression: String = "", // e.g. "3500+3260" or "400*21"
    val type: TransactionType,
    val categoryGroup: CategoryGroup,
    val categoryName: String,
    val subcategory: String = "",
    val monthYearKey: String, // e.g. "2026-08"
    val dateMillis: Long = System.currentTimeMillis(),
    val paymentAccount: String = "Cash", // e.g. "Cash", "bKash", "MTB Bank", "Meghna Bank", "Credit Card"
    val tags: String = "", // comma-separated e.g. "Rent,Home,ChargeWarning"
    val notes: String = "",
    val isPaid: Boolean = true,
    val plannedAmount: Double? = null, // e.g. 4500 planned vs 5026 actual
    val reminderDateMillis: Long? = null
)

@Entity(tableName = "budget_settings")
data class BudgetSettingEntity(
    @PrimaryKey
    val groupType: CategoryGroup,
    val targetPercentage: Float // e.g. 53 for Bills, 24 for Lifestyle, 23 for Debt & Savings
)

@Entity(tableName = "accountability_rules")
data class AccountabilityRuleEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val content: String,
    val category: String = "General", // "Rule", "Warning", "Principle"
    val isPinned: Boolean = true,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "future_plans")
data class FuturePlanEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val planType: PlanType = PlanType.DEBT_REPAYMENT,
    val totalTargetAmount: Double,
    val monthlyInstallmentAmount: Double,
    val startMonthKey: String, // e.g. "2026-08"
    val durationMonths: Int = 6, // number of months plan spans
    val paidAmount: Double = 0.0,
    val categoryGroup: CategoryGroup = CategoryGroup.DEBT_AND_SAVINGS,
    val categoryName: String = "Debt",
    val paymentAccount: String = "MTB Bank",
    val notes: String = "",
    val isCompleted: Boolean = false,
    val createdAtMillis: Long = System.currentTimeMillis()
)

data class MonthlySummary(
    val monthYearKey: String,
    val baseIncome: Double,
    val dailyRateIncome: Double,
    val extraIncome: Double,
    val totalIncome: Double,
    val billsTotal: Double,
    val lifestyleTotal: Double,
    val debtAndSavingsTotal: Double,
    val totalExpenses: Double,
    val netBalance: Double,
    val extraBuffer: Double,
    val billsPercentage: Float,
    val lifestylePercentage: Float,
    val debtSavingsPercentage: Float
)

